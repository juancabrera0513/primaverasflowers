// components/ProductCard.tsx
"use client";

import Image from "next/image";
import Link from "next/link";
import { useTransition, useState } from "react";
import { useRouter } from "next/navigation";

type Product = {
  id: string;
  slug: string;
  name_en: string;
  name_es: string;
  price_cents: number;
  primary_image_url?: string | null;
};

export default function ProductCard({
  product,
  lang = "en",
}: {
  product: Product;
  lang?: "en" | "es";
}) {
  const title = lang === "es" ? product.name_es : product.name_en;
  const price = (product.price_cents ?? 0) / 100;
  const router = useRouter();
  const [pendingAdd, startAdd] = useTransition();
  const [pendingBuy, startBuy] = useTransition();
  const [err, setErr] = useState<string | null>(null);

  const addToCart = async (redirectToCheckout = false) => {
    setErr(null);
    try {
      const res = await fetch("/api/cart/add", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ productId: product.id, quantity: 1 }),
      });
      if (!res.ok) throw new Error(await res.text());

      if (redirectToCheckout) {
        router.push(`/${lang}/checkout`);
      } else {
        window?.dispatchEvent(new Event("cart:updated"));
      }
    } catch (e: any) {
      setErr(e?.message ?? "Error");
      console.error(e);
    }
  };

  const onAdd = () => startAdd(() => addToCart(false));
  const onBuyNow = () => startBuy(() => addToCart(true));

  return (
    <div className="rounded-3xl bg-white shadow-sm ring-1 ring-[rgba(0,0,0,.06)] overflow-hidden group">
      <Link href={`/${lang}/product/${product.slug}`} className="block">
        <div className="relative w-full h-56 md:h-64 bg-[rgba(0,0,0,.04)]">
          {product.primary_image_url ? (
            <Image
              src={product.primary_image_url}
              alt={title}
              fill
              sizes="(max-width: 768px) 100vw, (max-width: 1200px) 33vw, 33vw"
              className="object-cover transition-transform duration-300 group-hover:scale-[1.03]"
              priority={false}
            />
          ) : (
            <div className="absolute inset-0 flex items-center justify-center text-sm opacity-60">
              No image
            </div>
          )}
        </div>
      </Link>

      <div className="p-4">
        <Link href={`/${lang}/product/${product.slug}`} className="block">
          <h3 className="text-lg font-semibold leading-tight" style={{ color: "var(--fg)" }}>
            {title}
          </h3>
        </Link>

        <p className="mt-1 text-base font-medium" style={{ color: "var(--fg)" }}>
          {price.toLocaleString(lang, { style: "currency", currency: "USD" })}
        </p>

        <div className="mt-3 flex items-center gap-3">
          <button
            onClick={onAdd}
            disabled={pendingAdd}
            className="inline-flex items-center justify-center rounded-2xl px-4 py-2 font-semibold
                       shadow-sm transition-all
                       bg-[var(--olive)] text-white
                       hover:brightness-110 hover:shadow-md
                       focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--ring)]
                       disabled:opacity-60 disabled:cursor-not-allowed"
          >
            {pendingAdd ? (lang === "es" ? "Agregando..." : "Adding...") : lang === "es" ? "Agregar" : "Add to cart"}
          </button>

          <button
            onClick={onBuyNow}
            disabled={pendingBuy}
            className="inline-flex items-center justify-center rounded-2xl px-4 py-2 font-semibold
                       shadow-sm transition-all border
                       border-[rgba(0,0,0,.12)] text-[var(--fg)]
                       hover:bg-[rgba(0,0,0,.04)] hover:shadow-md
                       focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--ring)]
                       disabled:opacity-60 disabled:cursor-not-allowed"
          >
            {pendingBuy ? (lang === "es" ? "Redirigiendo..." : "Redirecting...") : lang === "es" ? "Comprar" : "Buy now"}
          </button>
        </div>

        {err && (
          <p className="mt-2 text-sm" style={{ color: "var(--terracotta)" }}>
            {err}
          </p>
        )}
      </div>
    </div>
  );
}
