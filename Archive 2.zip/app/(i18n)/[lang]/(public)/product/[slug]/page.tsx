// app/(i18n)/[lang]/(public)/product/[slug]/page.tsx
import Image from "next/image";
import { notFound } from "next/navigation";
import { getDictionary, isLang, type Lang } from "@/lib/i18n";
import { createPublicServerClient } from "@/lib/supabase-client";
import Meta from "@/lib/metadata"; // ← el objeto exportado arriba { ProductJsonLd }
import VariantSelector from "@/components/VariantSelector";
import AddonSelector from "@/components/AddonSelector";
import DeliveryPicker from "@/components/DeliveryPicker";

export default async function ProductPage({
  params,
}: {
  params: Promise<{ lang: string; slug: string }>;
}) {
  const { lang, slug } = await params;
  const locale: Lang = isLang(lang) ? lang : "en";
  const dict = await getDictionary(locale);

  const supabase = createPublicServerClient();

  const { data: product, error } = await supabase
    .from("products")
    .select(
      `
      id, slug, name_en, name_es, description_en, description_es,
      price_cents, primary_image_url, is_active,
      product_variants(id, name, price_delta_cents, sort),
      images:product_images(id, image_url, sort),
      product_addons(
        addon_id,
        addon:addons(id, name_en, name_es, price_cents)
      )
    `
    )
    .eq("slug", slug)
    .eq("is_active", true)
    .single();

  if (error) console.error("[product] error:", error);
  if (!product) notFound();

  const title = locale === "es" ? product.name_es : product.name_en;
  const desc =
    locale === "es" ? product.description_es ?? "" : product.description_en ?? "";
  const basePrice = (product.price_cents ?? 0) / 100;

  return (
    <div className="container-narrow py-8 md:py-10">
      {/* JSON-LD */}
      {Meta.ProductJsonLd(product).render(locale)}

      <div className="grid md:grid-cols-2 gap-8">
        <div className="rounded-3xl overflow-hidden bg-[rgba(0,0,0,.04)] min-h-[320px] relative">
          {product.primary_image_url ? (
            <Image
              src={product.primary_image_url}
              alt={title}
              fill
              className="object-cover"
              sizes="(max-width: 768px) 100vw, 50vw"
            />
          ) : (
            <div className="absolute inset-0 grid place-items-center text-sm opacity-60">
              No image
            </div>
          )}
        </div>

        <div>
          <h1 className="text-3xl md:text-4xl font-extrabold" style={{ color: "var(--fg)" }}>
            {title}
          </h1>
          {desc && (
            <p className="mt-2 text-[var(--fg-muted)]">
              {desc}
            </p>
          )}
          <p className="mt-4 text-xl font-semibold" style={{ color: "var(--fg)" }}>
            {basePrice.toLocaleString(locale, { style: "currency", currency: "USD" })}
          </p>

          {/* Controles (opcionales) */}
          <div className="mt-6 space-y-5">
            <VariantSelector
              variants={product.product_variants ?? []}
              lang={locale}
            />
            <AddonSelector
              addons={(product.product_addons ?? []).map((x: any) => x.addon)}
              lang={locale}
            />
            <DeliveryPicker lang={locale} />
          </div>
        </div>
      </div>
    </div>
  );
}
