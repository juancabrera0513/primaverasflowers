// app/(i18n)/[lang]/(public)/catalog/page.tsx
import { getDictionary, isLang, type Lang } from "@/lib/i18n";
import supabasePublic from "@/lib/supabase-client";
import ProductCard from "@/components/ProductCard";

export const revalidate = 60;

export default async function CatalogPage({
  params,
}: {
  params: Promise<{ lang: string }>;
}) {
  const { lang } = await params;
  const locale: Lang = isLang(lang) ? lang : "en";
  const dict = await getDictionary(locale);

  const { data: products, error } = await supabasePublic
    .from("products")
    .select("id, slug, name_en, name_es, price_cents, primary_image_url, is_active, sort")
    .eq("is_active", true)
    .order("sort", { ascending: true, nullsFirst: false });

  if (error) {
    console.error("[catalog] products error:", error);
  }

  const list = Array.isArray(products) ? products : [];

  return (
    <div>
      <div className="container-narrow py-8 md:py-10">
        <h1 className="text-3xl md:text-4xl font-extrabold mb-2" style={{ color: "var(--fg)" }}>
          {dict.catalog?.title ?? "Catalog"}
        </h1>
        <p className="text-base" style={{ color: "var(--fg-muted)" }}>
          {dict.catalog?.subtitle ?? "Fresh arrangements, ready for same-day delivery."}
        </p>
      </div>

      <div className="container-narrow pb-16">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {list.map((p) => (
            <ProductCard key={p.id} product={p} lang={locale} />
          ))}
        </div>
      </div>
    </div>
  );
}
