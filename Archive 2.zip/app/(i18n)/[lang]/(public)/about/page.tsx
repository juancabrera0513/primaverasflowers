// app/(i18n)/[lang]/(public)/about/page.tsx
import { StoreInfo } from "@/components/StoreInfo";

export const metadata = {
  title: "About Us — Primavera Flowers NYC",
  description:
    "Learn about Primavera Flowers NYC: customer-first floral design, fresh arrangements, plants, gift baskets and more.",
};

export default async function AboutPage() {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Florist",
    "name": "Primavera Flowers NYC",
    "telephone": "+1-917-770-1684",
    "address": {
      "@type": "PostalAddress",
      "streetAddress": "463 Fort Washington Ave",
      "addressLocality": "New York",
      "addressRegion": "NY",
      "postalCode": "10033",
      "addressCountry": "US"
    },
    "openingHoursSpecification": [
      { "@type": "OpeningHoursSpecification", "dayOfWeek": "Sunday",    "opens": "09:00", "closes": "18:00" },
      { "@type": "OpeningHoursSpecification", "dayOfWeek": "Monday",    "opens": "09:00", "closes": "18:00" },
      { "@type": "OpeningHoursSpecification", "dayOfWeek": "Tuesday",   "opens": "09:00", "closes": "18:00" },
      { "@type": "OpeningHoursSpecification", "dayOfWeek": "Wednesday", "opens": "09:00", "closes": "18:00" },
      { "@type": "OpeningHoursSpecification", "dayOfWeek": "Thursday",  "opens": "09:00", "closes": "18:00" },
      { "@type": "OpeningHoursSpecification", "dayOfWeek": "Friday",    "opens": "09:00", "closes": "18:00" },
      { "@type": "OpeningHoursSpecification", "dayOfWeek": "Saturday",  "opens": "09:00", "closes": "18:00" }
    ],
    "url": "https://example.com/about"
  };

  const specialtyServices = [
    "Large inventory of fresh flowers for any occasion",
    "Weddings / Wedding Flowers",
    "Sympathy and Funeral flowers",
    "Birthday Flowers, Get Well Flowers, Anniversary Flowers",
    "Plants",
    "European/dish gardens",
    "Modern and traditional flower arrangements",
    "High-style floral arrangements",
    "Silk flower arrangements",
    "Dried floral arrangements",
    "Extensive gift line",
    "Gourmet fruit baskets",
    "Gift baskets",
    "Greeting cards",
  ];

  return (
    <>
      <section className="section-alt">
        <div className="container-narrow py-10">
          <h1 className="text-3xl md:text-4xl font-extrabold mb-3" style={{ color: "var(--fg)" }}>
            About Us
          </h1>
          <p className="text-lg" style={{ color: "var(--fg-muted)" }}>
            Primavera Flowers NYC proudly serves the New York area. We are committed to providing great
            customer service, the finest floral arrangements, beautiful floral designs, as well as gift
            baskets and much more. Our customers are important to us and our friendly staff is dedicated
            to making your experience a pleasant one. We will always go the extra mile to make your floral gift perfect!
          </p>
          <p className="mt-3" style={{ color: "var(--fg-muted)" }}>
            You can expect great customer service, fresh flower arrangements, beautiful floral designs,
            plants, gift baskets and much more. Make Primavera Flowers NYC your first choice for flowers.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container-narrow py-10">
          <div className="grid lg:grid-cols-3 gap-6">
            <div className="card lg:col-span-2">
              <h2 className="text-2xl font-bold mb-3" style={{ color: "var(--fg)" }}>
                About Our Company.
              </h2>
              <p style={{ color: "var(--fg-muted)" }}>
                Primavera Flowers NYC
                <br />
                463 Fort Washington Ave
                <br />
                New York, NY 10033
              </p>

              <h3 className="text-xl font-semibold mt-6 mb-2">Specialty Services</h3>
              <ul className="list-disc pl-5 leading-7" style={{ color: "var(--fg-muted)" }}>
                {specialtyServices.map((s) => <li key={s}>{s}</li>)}
              </ul>
            </div>

            <div className="card">
              <StoreInfo />
            </div>
          </div>
        </div>
      </section>

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
    </>
  );
}
