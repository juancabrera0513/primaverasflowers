// app/(i18n)/[lang]/(public)/page.tsx
import Link from "next/link";
import { getDictionary } from "@/lib/i18n";

export default async function HomePage({ params }:{ params: Promise<{ lang:string }> }){
  const { lang } = await params;
  const dict = await getDictionary(lang);

  return (
    <>
      {/* HERO sobre superficie blanca (alto contraste con botones) */}
      <section className="section">
        <div className="container-narrow grid md:grid-cols-2 gap-8 items-center py-10">
          <div>
            <span className="chip mb-3">{dict.common.home.badge}</span>
            <h1 className="text-4xl md:text-5xl font-extrabold mb-4" style={{ color:"var(--fg)" }}>
              {dict.common.home.headline}
            </h1>
            <p className="text-lg" style={{ color:"var(--fg-muted)" }}>
              {dict.common.home.sub}
            </p>
            <div className="mt-6 flex gap-3">
              <Link className="btn btn-primary" href={`/${lang}/catalog`}>
                {dict.common.home.ctaShop}
              </Link>
              <Link className="btn btn-outline" href={`/${lang}/about`}>
                {dict.common.home.ctaAbout}
              </Link>
            </div>
          </div>

          <div className="rounded-2xl overflow-hidden shadow-soft"
               style={{ background:"var(--surface)", border:"1px solid var(--border)" }}>
            <img src="/og-default.jpg" alt="Flowers" className="w-full h-auto" />
          </div>
        </div>
      </section>

      {/* Sección alterna (ligeramente más oscura que bg) */}
      <section className="section-alt">
        <div className="container-narrow py-10">
          <h2 className="text-2xl font-bold mb-4" style={{ color:"var(--fg)" }}>
            {dict.common.home.featured}
          </h2>
          <p style={{ color:"var(--fg-muted)" }}>{dict.common.home.featuredSub}</p>
        </div>
      </section>
    </>
  );
}
