// app/(i18n)/[lang]/layout.tsx
import type { Metadata } from "next";
import Link from "next/link";
import { getDictionary, isSupportedLang } from "@/lib/i18n";
import { LanguageSwitcher } from "@/components/LanguageSwitcher";
import { getLangAlternates } from "@/lib/metadata";

export async function generateMetadata({ params }:{ params: Promise<{ lang:string }> }):Promise<Metadata>{
  const { lang } = await params;
  const safe = isSupportedLang(lang) ? lang : "en";
  return { alternates:{ languages: getLangAlternates(safe) } };
}

export default async function I18nLayout({
  children, params,
}:{ children:React.ReactNode; params: Promise<{ lang:string }> }){
  const { lang } = await params;
  const dict = await getDictionary(lang);

  return (
    <div className="min-h-screen flex flex-col">
      {/* ✅ Ahora con clase .site-header (forzada en CSS) */}
      <header className="site-header">
        <div className="container-narrow py-4 flex items-center justify-between">
          <Link href={`/${lang}`} className="flex items-center gap-3 group">
            <img src="/logo.svg" alt="Primavera Flowers" className="h-8 w-8 rounded-full" />
            <span className="font-bold tracking-tight text-white group-hover:opacity-90 transition-opacity">
              Primavera Flowers
            </span>
          </Link>
          <nav className="flex items-center gap-6">
            <Link href={`/${lang}/catalog`}>{dict.common.nav.catalog}</Link>
            <Link href={`/${lang}/about`}>{dict.common.nav.about}</Link>
            <Link href={`/${lang}/contact`}>{dict.common.nav.contact}</Link>
            <Link href={`/${lang}/cart`}>{dict.common.nav.cart}</Link>
            <LanguageSwitcher lang={lang as "en" | "es"} variant="inverted" />
          </nav>
        </div>
      </header>

      <main className="flex-1">{children}</main>

      <footer className="border-t" style={{ background:"var(--surface)", borderColor:"var(--border)" }}>
        <div className="container-narrow py-6 text-sm" style={{ color:"var(--fg-muted)" }}>
          © {new Date().getFullYear()} Primavera Flowers — {dict.common.footer.rights}
        </div>
      </footer>
    </div>
  );
}
