// next.config.mjs
/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    remotePatterns: [
      { protocol: "https", hostname: "images.unsplash.com" },
      { protocol: "https", hostname: "picsum.photos" },     // por si dejas alguna
      { protocol: "https", hostname: "**.supabase.co" },    // futuro bucket
    ],
  },
};

export default nextConfig;
