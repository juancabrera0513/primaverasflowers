// lib/metadata.tsx
// ⬅️ Asegúrate de que sea .tsx (no .ts) porque devuelve JSX para JSON-LD
import React from "react";
import type { Metadata } from "next";

type Lang = "en" | "es";

function toJson(obj: unknown) {
  return JSON.stringify(obj).replace(/</g, "\\u003c");
}

/** Metadatos base del sitio (para app/layout.tsx) */
export function getDefaultMetadata(): Metadata {
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";
  const title = "Primavera Flowers";
  const description =
    "Fresh flowers, same-day delivery. Primavera Flowers NYC — bouquets, arrangements and plants.";

  return {
    metadataBase: new URL(siteUrl),
    title: {
      default: title,
      template: `%s | ${title}`,
    },
    description,
    icons: [
      { rel: "icon", url: "/favicon.ico" },
      { rel: "apple-touch-icon", url: "/apple-touch-icon.png" },
    ],
    openGraph: {
      type: "website",
      url: siteUrl,
      siteName: title,
      title,
      description,
      images: [{ url: "/og.jpg", width: 1200, height: 630, alt: title }],
      locale: "en_US",
    },
    alternates: {
      canonical: siteUrl,
      languages: {
        en: "/en",
        es: "/es",
      },
    },
    robots: {
      index: true,
      follow: true,
    },
  };
}

/** Metadatos por página (opcional) */
export function getPageMetadata(opts: {
  title?: string;
  description?: string;
  path?: string; // p.ej. "/product/rose-bouquet"
  image?: string; // absoluta o relativa
}): Metadata {
  const base = getDefaultMetadata();
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";
  const url = opts.path ? new URL(opts.path, siteUrl).toString() : siteUrl;
  const ogImage =
    opts.image ??
    (base.openGraph && Array.isArray(base.openGraph.images) && base.openGraph.images[0]
      ? (base.openGraph.images[0] as any).url
      : "/og.jpg");

  return {
    ...base,
    title: opts.title
      ? { default: opts.title, template: `%s | Primavera Flowers` }
      : base.title,
    description: opts.description ?? base.description,
    openGraph: {
      ...(base.openGraph ?? {}),
      url,
      title: opts.title ?? (typeof base.title === "string" ? base.title : "Primavera Flowers"),
      description: opts.description ?? base.description,
      images: [{ url: ogImage }],
    },
    alternates: {
      canonical: url,
      languages: {
        en: url.replace("/es", "/en"),
        es: url.replace("/en", "/es"),
      },
    },
  };
}

/** JSON-LD para producto */
function ProductJsonLd(product: {
  slug: string;
  name_en: string;
  name_es: string;
  description_en?: string | null;
  description_es?: string | null;
  price_cents: number;
  primary_image_url?: string | null;
}) {
  const price = (product.price_cents ?? 0) / 100;
  return {
    render(lang: Lang = "en") {
      const name = lang === "es" ? product.name_es : product.name_en;
      const description =
        lang === "es" ? product.description_es : product.description_en;

      const json = {
        "@context": "https://schema.org",
        "@type": "Product",
        name,
        description,
        image: product.primary_image_url || undefined,
        offers: {
          "@type": "Offer",
          price: price.toFixed(2),
          priceCurrency: "USD",
          availability: "https://schema.org/InStock",
        },
      };

      return (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: toJson(json) }}
        />
      );
    },
  };
}

export { ProductJsonLd };

// Export por defecto (conveniencia)
export default {
  getDefaultMetadata,
  getPageMetadata,
  ProductJsonLd,
};
